# Anime Shader Studio v1.2

**Taper improvement:** The old taper affected entire Freestyle chains. v1.2 makes interior tapers much longer (32% at each end), defaults to fine round tips, and adds an option to split long Freestyle chains (default target length 90 px). Splitting may add visible joins; adjust this control or disable it if the result is too segmented.

**Install:** Blender > Edit > Preferences > Add-ons > Install from Disk, select v1.2 ZIP, enable, open N-panel > Anime Shader, and press **Apply Outline Settings**. Remove or disable an older installed copy before enabling v1.2. Render with F12; Freestyle is not a regular material viewport effect.

**Testing:** This version is syntax-checked but not render-tested inside Blender. The taper applies at generated *stroke* endpoints, not at every underlying mesh edge or visible overlap. If very short lines are still blunt, check line style > Thickness > ASS | End Taper is enabled, and try increasing inner line thickness to 2–3 px temporarily to inspect the taper.

# Anime Shader Studio 1.1 — Blender 4.5+

## Installation
1. Edit → Preferences → Add-ons → dropdown → Install from Disk.
2. Select `anime_shader_studio.zip` and enable the add-on.
3. Select meshes and open 3D View → N panel → **Anime Shader**.
4. Choose color bands and palette type. Click **Create / Update Selected Materials**.
5. Enable outlines, set thick silhouette and thin internal line sizes, then click **Apply Outline Settings**.
6. Optional: enable compositor glow and click **Apply Glow Compositor**.
7. Render with **F12**; Image → Save As → PNG or JPEG.

## New in 1.1 — tapered ink stroke tips
In the **3. Freestyle Ink** section:
- **Taper Interior Ends** (on by default): points the ends of short crease/detail lines, such as the mountain texture lines in your example.
- **Interior Taper Length** (default 17%): percentage of the generated stroke's total length tapered at *each* end.
- **Taper Silhouette Ends** (off by default): independently taper uninterrupted outer contours if desired. For a solid anime silhouette, leave this off.
- **Silhouette Taper Length** (default 8%): controls outer stroke taper separately.
- **Tip Width** (default 5%): percentage of full width at each tip. Set to 0 for a sharp point.

Click **Apply Outline Settings** after changing these controls, then **F12** to render. Freestyle computes these relative to *generated strokes*, not every mesh edge. On closed outlines or where Freestyle joins edges, the ends may be elsewhere than expected. If the goal is to taper only *dangling ends* but never loop seams, that requires an additional stroke-topology processing approach.

## Notes
- Uses EEVEE Shader to RGB: Cycles is unsupported.
- The material responds to Blender scene lighting and cast shadows. Band colors are color values, rather than a physically based surface response.
- Scene lighting may need adjustment using the Light Gain and Light Offset controls to distribute bands properly.
- Palette-from-image uses RGB centroid clustering of sampled nontransparent pixels, then orders the result by brightness. It does **not** preserve image composition or assign sampled colors to particular textures.
- Image palettes and custom colors are provided in Blender's node color space. Screen appearance depends on scene view transform.
- Gloss is a stylized thresholded reflection response; it is **not** real glass transmission/refraction.
- Emission and glow are different: emission changes the material's rendered brightness; **Compositor Glow** adds a 2D bloom around bright pixels.
- Freestyle pop strokes correspond to silhouettes, contours and mesh borders; fine lines use creases and optional material boundaries. These are render-time view-dependent lines, not an exact per-pixel test of "one face visible" versus "both visible". Freestyle can't draw a line for every arbitrary coplanar edge.
- Freestyle and compositor glow appear in the **F12 final render**, not ordinary material-preview shading.
- Outline configuration applies to the whole scene/view layers, not just the selected object. It adds two managed line sets; existing unrelated Freestyle sets remain in place and can also render. You may disable other line sets in View Layer Properties to avoid duplicates.
- Applying the shader replaces the FIRST material slot for selected objects if they do not already have an Anime Shader Studio material. It leaves additional slots untouched. Save a backup before first use.
- The glow tool routes Render Layers → Glow → Composite when enabled, replacing the existing connection to Composite. Complex compositor setups should be backed up before applying glow. Turning glow off deletes its managed node; reconnect an existing compositor pipeline manually if needed.
- Settings are scene-level. The material node graph is rebuilt only when you click Create / Update. Shared materials update on all objects using them.

## Tips
- For eye highlights: 2–3 shade bands, Gloss on, low Roughness, modest Glint Threshold.
- For manga/grayscale: enable Grayscale Override, 3–5 bands and black ink.
- For anime paints: 3–4 bands, high contrast shadows, Pop 3–5 px, Crease 0.8–1.5 px.
- For glowing accents: enable Emission with strength >1, plus Compositor Glow.

- This patch does not retroactively change an existing scene until **Apply Outline Settings** is clicked.
