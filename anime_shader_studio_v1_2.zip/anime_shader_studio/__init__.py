bl_info = {
    'name': 'Anime Shader Studio',
    'author': 'OpenAI',
    'version': (1, 2, 0),
    'blender': (4, 5, 0),
    'location': 'View3D > Sidebar > Anime Shader',
    'description': 'Lighting-aware toon materials, image palettes, Freestyle outlines and optional glow',
    'category': 'Material',
}

import bpy
import colorsys
import math
import random
from bpy.props import (BoolProperty, FloatProperty, FloatVectorProperty, IntProperty,
                       EnumProperty, PointerProperty, CollectionProperty)
from bpy.types import Operator, Panel, PropertyGroup, UIList

PREFIX = 'ASS | '


def srgb_to_linear(v):
    return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4


def linear_to_srgb(v):
    v = max(0.0, min(1.0, v))
    return 12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055


def color_value(c):
    return 0.2126*c[0] + 0.7152*c[1] + 0.0722*c[2]


class ASS_PaletteColor(PropertyGroup):
    color: FloatVectorProperty(name='Band Color', subtype='COLOR', size=4,
                              min=0.0, max=1.0, default=(0.5, 0.5, 0.5, 1.0))


class ASS_Settings(PropertyGroup):
    bands: IntProperty(name='Color Bands', default=4, min=2, max=12)
    palette_mode: EnumProperty(name='Palette', items=[
        ('GENERATED', 'Generated', 'Create shades from the base color'),
        ('CUSTOM', 'Custom', 'Manually edit each band'),
        ('IMAGE', 'From Image', 'Extract predominant colors from an image')], default='GENERATED')
    base_color: FloatVectorProperty(name='Base Color', subtype='COLOR', size=3, min=0, max=1,
                                    default=(0.7, 0.45, 0.30))
    shadow_strength: FloatProperty(name='Shadow Depth', default=0.72, min=0, max=1)
    highlight_strength: FloatProperty(name='Light Strength', default=0.22, min=0, max=1)
    band_offset: FloatProperty(name='Light Offset', default=0.0, min=-0.9, max=0.9)
    band_spread: FloatProperty(name='Band Spread', default=1.0, min=0.15, max=3.0)
    light_gain: FloatProperty(name='Light Gain', default=1.0, min=0.1, max=5.0)
    grayscale: BoolProperty(name='Grayscale Override', default=False)
    palette: CollectionProperty(type=ASS_PaletteColor)
    source_image: PointerProperty(name='Reference Image', type=bpy.types.Image)
    sample_limit: IntProperty(name='Sample Budget', default=5000, min=500, max=20000)
    gloss: BoolProperty(name='Glossy Toon Highlights', default=False)
    gloss_color: FloatVectorProperty(name='Glint Color', subtype='COLOR', size=3, min=0, max=1,
                                      default=(1, 1, 1))
    gloss_threshold: FloatProperty(name='Glint Threshold', default=0.72, min=0.01, max=0.99)
    gloss_strength: FloatProperty(name='Glint Strength', default=0.8, min=0, max=3)
    roughness: FloatProperty(name='Gloss Roughness', default=0.16, min=0.01, max=1)
    emission: BoolProperty(name='Emission', default=False)
    emission_color: FloatVectorProperty(name='Emission Color', subtype='COLOR', size=3,
                                         min=0, max=1, default=(1.0, 0.65, 0.25))
    emission_strength: FloatProperty(name='Emission Strength', default=2.0, min=0, max=50)
    glow: BoolProperty(name='Compositor Glow', default=False)
    glow_threshold: FloatProperty(name='Glow Threshold', default=1.0, min=0, max=10)
    outline: BoolProperty(name='Enable Outlines', default=True)
    outer_thickness: FloatProperty(name='Pop / Silhouette (px)', default=3.5, min=0.1, max=40)
    inner_thickness: FloatProperty(name='Interior / Crease (px)', default=1.2, min=0.1, max=40)
    outer_taper: BoolProperty(name='Taper Silhouette Ends', default=False,
                              description='Reduce silhouette stroke thickness towards both ends')
    inner_taper: BoolProperty(name='Taper Interior Ends', default=True,
                              description='Create pointed tips on interior detail strokes')
    outer_taper_length: FloatProperty(name='Silhouette Taper Length', default=0.08, min=0.01, max=0.49,
                                      subtype='FACTOR', description='Fraction of each stroke length tapered at each end')
    inner_taper_length: FloatProperty(name='Interior Taper Length', default=0.32, min=0.01, max=0.49,
                                      subtype='FACTOR', description='Fraction of each stroke length tapered at each end')
    taper_tip: FloatProperty(name='Tip Width', default=0.0, min=0.0, max=1.0, subtype='FACTOR',
                             description='End width as a fraction of full stroke thickness; 0 makes a sharp point')
    inner_stroke_split: BoolProperty(name='Split Interior Strokes', default=True,
        description='Break long joined creases into separate ink strokes so their ends can taper')
    inner_split_length: FloatProperty(name='Stroke Segment Length (px)', default=90.0, min=10.0, max=2000.0,
        description='Approximate maximum screen-space length of Freestyle interior strokes')
    outline_color: FloatVectorProperty(name='Ink Color', subtype='COLOR', size=3, min=0, max=1,
                                        default=(0.025, 0.018, 0.035))
    crease_angle: FloatProperty(name='Crease Angle', default=45, min=0, max=180,
                                description='Stored in degrees as numerical angle (not Blender angle UI conversion)')
    use_crease: BoolProperty(name='Draw Creases', default=True)
    use_material_edges: BoolProperty(name='Draw Material Boundaries', default=False)


def ensure_palette(s):
    while len(s.palette) < s.bands:
        s.palette.add()
    while len(s.palette) > s.bands:
        s.palette.remove(len(s.palette)-1)


def generated(s):
    base = list(s.base_color)
    h, sat, value = colorsys.rgb_to_hsv(*base)
    out = []
    for i in range(s.bands):
        t = i / (s.bands - 1)
        # Shadow bands darken the base, highlights brighten it.
        if t < 0.5:
            factor = (1.0 - s.shadow_strength) + (s.shadow_strength * t / 0.5)
            rgb = tuple(v * factor for v in base)
        else:
            fraction = (t - 0.5) / 0.5
            rgb = tuple(v + (1.0 - v) * s.highlight_strength * fraction for v in base)
        out.append((*rgb, 1.0))
    return out


def palette_colors(s):
    ensure_palette(s)
    if s.grayscale:
        return [(i/(s.bands-1),)*3 + (1.0,) for i in range(s.bands)]
    if s.palette_mode == 'GENERATED':
        return generated(s)
    return [tuple(s.palette[i].color) for i in range(s.bands)]


def new_node(nodes, typ, label, x, y):
    n = nodes.new(typ)
    n.label = label
    n.location = (x, y)
    return n


def set_default(socket, value):
    if socket is not None:
        socket.default_value = value


def build_material(s, mat):
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    nodes, links = nt.nodes, nt.links
    output = new_node(nodes, 'ShaderNodeOutputMaterial', 'Output', 1300, 150)
    diffuse = new_node(nodes, 'ShaderNodeBsdfDiffuse', 'Scene lights and shadows', -1050, 280)
    diffuse.inputs['Color'].default_value = (1, 1, 1, 1)
    diffuse.inputs['Roughness'].default_value = 0.0
    light_rgb = new_node(nodes, 'ShaderNodeShaderToRGB', 'EEVEE lighting intensity', -800, 280)
    links.new(diffuse.outputs['BSDF'], light_rgb.inputs['Shader'])
    bw = new_node(nodes, 'ShaderNodeRGBToBW', 'Brightness', -590, 280)
    links.new(light_rgb.outputs['Color'], bw.inputs['Color'])
    mul = new_node(nodes, 'ShaderNodeMath', 'Light Gain', -380, 280)
    mul.operation = 'MULTIPLY'
    mul.inputs[1].default_value = s.light_gain
    links.new(bw.outputs['Val'], mul.inputs[0])
    ramp = new_node(nodes, 'ShaderNodeValToRGB', 'Discrete toon palette', -140, 280)
    links.new(mul.outputs[0], ramp.inputs['Fac'])
    ramp.color_ramp.interpolation = 'CONSTANT'
    colors = palette_colors(s)
    cr = ramp.color_ramp
    # positions vary around a central axis, light offset translates the ramp
    for i, c in enumerate(colors):
        el = cr.elements[i] if i < 2 else cr.elements.new(0.5)
        pos = (i / s.bands) * s.band_spread + s.band_offset
        el.position = max(0.0, min(1.0, pos))
        el.color = c
    base_emission = new_node(nodes, 'ShaderNodeEmission', 'Toon color (unlit final)', 600, 230)
    links.new(ramp.outputs['Color'], base_emission.inputs['Color'])
    base_emission.inputs['Strength'].default_value = 1.0
    current = base_emission.outputs[0]
    if s.gloss:
        glossy = new_node(nodes, 'ShaderNodeBsdfGlossy', 'Scene-light reflections', -1040, -230)
        glossy.inputs['Color'].default_value = (1, 1, 1, 1)
        glossy.inputs['Roughness'].default_value = s.roughness
        glossy_rgb = new_node(nodes, 'ShaderNodeShaderToRGB', 'Specular intensity', -800, -230)
        links.new(glossy.outputs[0], glossy_rgb.inputs[0])
        grey = new_node(nodes, 'ShaderNodeRGBToBW', 'Specular brightness', -590, -230)
        links.new(glossy_rgb.outputs['Color'], grey.inputs['Color'])
        glint_ramp = new_node(nodes, 'ShaderNodeValToRGB', 'Hard glint threshold', -360, -230)
        glint_ramp.color_ramp.interpolation = 'CONSTANT'
        glint_ramp.color_ramp.elements[0].position = 0.0
        glint_ramp.color_ramp.elements[0].color = (0,0,0,1)
        glint_ramp.color_ramp.elements[1].position = s.gloss_threshold
        glint_ramp.color_ramp.elements[1].color = (*s.gloss_color, 1)
        links.new(grey.outputs['Val'], glint_ramp.inputs['Fac'])
        glint = new_node(nodes, 'ShaderNodeEmission', 'Glint', 120, -230)
        glint.inputs['Strength'].default_value = s.gloss_strength
        links.new(glint_ramp.outputs['Color'], glint.inputs['Color'])
        add = new_node(nodes, 'ShaderNodeAddShader', 'Add stylized specular', 850, 70)
        links.new(current, add.inputs[0])
        links.new(glint.outputs[0], add.inputs[1])
        current = add.outputs[0]
    if s.emission:
        e = new_node(nodes, 'ShaderNodeEmission', 'Extra emission', 650, -430)
        e.inputs['Color'].default_value = (*s.emission_color, 1.0)
        e.inputs['Strength'].default_value = s.emission_strength
        add = new_node(nodes, 'ShaderNodeAddShader', 'Add glow source', 1050, 0)
        links.new(current, add.inputs[0])
        links.new(e.outputs[0], add.inputs[1])
        current = add.outputs[0]
    links.new(current, output.inputs['Surface'])
    mat.diffuse_color = colors[min(len(colors)-1, len(colors)//2)]
    mat['ass_material'] = True
    return mat


def add_lineset(fs, name, thick, color, outer):
    ls = fs.linesets.get(name) or fs.linesets.new(name)
    ls.select_by_visibility = True
    ls.visibility = 'VISIBLE'
    ls.select_silhouette = bool(outer)
    ls.select_contour = bool(outer)
    ls.select_border = bool(outer)
    ls.select_crease = not outer
    ls.select_edge_mark = False
    ls.select_external_contour = False
    ls.select_suggestive_contour = False
    ls.select_ridge_valley = False
    ls.select_material_boundary = False
    ls.linestyle.thickness = thick
    ls.linestyle.color = tuple(color)
    ls.linestyle.alpha = 1.0
    return ls


def set_stroke_taper(linestyle, enabled, width, length, tip):
    """Make a hard-to-miss, symmetric width falloff at BOTH stroke ends.

    Thickness is set in pixel units, not opacity. The modifier's mapping is
    evaluated once over each *Freestyle stroke*, so chaining/splitting affects
    where the taper actually falls. Rebuild owned modifier on every Apply.
    """
    modifier_name = PREFIX + 'End Taper'
    for modifier in list(linestyle.thickness_modifiers):
        if modifier.name == modifier_name:
            linestyle.thickness_modifiers.remove(modifier)
    linestyle.caps = 'ROUND' if enabled else 'BUTT'
    if not enabled:
        return
    modifier = linestyle.thickness_modifiers.new(modifier_name, 'ALONG_STROKE')
    modifier.use = True
    modifier.blend = 'MIX'
    modifier.influence = 1.0
    modifier.mapping = 'CURVE'
    # A small but nonzero end is more robust than a true zero-width tip.
    # Blender's Freestyle engine can drop extremely thin endpoints.
    modifier.value_min = max(0.01, width * max(0.0, tip))
    modifier.value_max = width
    mapping = modifier.curve
    curve = mapping.curves[0]
    for point in list(curve.points)[1:-1]:
        curve.points.remove(point)
    curve.points[0].location = (0.0, 0.0)
    curve.points[-1].location = (1.0, 0.0)
    left = curve.points.new(length, 1.0)
    right = curve.points.new(1.0 - length, 1.0)
    # Precise profile (rather than the rounded AUTO default): 0 -> full -> full -> 0.
    for point in curve.points:
        point.handle_type = 'VECTOR'
    mapping.update()


def setup_outlines(context, s):
    scene = context.scene
    if scene.render.engine != 'BLENDER_EEVEE_NEXT':
        scene.render.engine = 'BLENDER_EEVEE_NEXT'
    scene.render.use_freestyle = s.outline
    scene.render.line_thickness_mode = 'ABSOLUTE'
    for view_layer in scene.view_layers:
        fs = view_layer.freestyle_settings
        fs.mode = 'EDITOR'
        fs.crease_angle = math.radians(s.crease_angle)
        fs.use_material_boundaries = s.use_material_edges
        outer = add_lineset(fs, PREFIX + 'Pop / Silhouette', s.outer_thickness, s.outline_color, True)
        inner = add_lineset(fs, PREFIX + 'Interior / Crease', s.inner_thickness, s.outline_color, False)
        set_stroke_taper(outer.linestyle, s.outer_taper, s.outer_thickness,
                         s.outer_taper_length, s.taper_tip)
        set_stroke_taper(inner.linestyle, s.inner_taper, s.inner_thickness,
                         s.inner_taper_length, s.taper_tip)
        # Split long chained edges, otherwise their intermediate visible
        # endpoints will not receive a taper (modifier affects whole stroke).
        if hasattr(inner.linestyle, 'use_split_length'):
            inner.linestyle.use_split_length = bool(s.inner_taper and s.inner_stroke_split)
            if inner.linestyle.use_split_length:
                inner.linestyle.split_length = s.inner_split_length
        inner.show_render = s.use_crease
        if s.use_material_edges:
            inner.select_material_boundary = True
    return True


def setup_glow(scene, s):
    if not s.glow:
        if scene.use_nodes and scene.node_tree:
            for n in list(scene.node_tree.nodes):
                if n.name == PREFIX + 'Glow':
                    scene.node_tree.nodes.remove(n)
        return
    scene.use_nodes = True
    nodes, links = scene.node_tree.nodes, scene.node_tree.links
    glow = nodes.get(PREFIX + 'Glow')
    if glow is None:
        glow = nodes.new('CompositorNodeGlare')
        glow.name = PREFIX + 'Glow'
        glow.location = (180, 80)
    glow.glare_type = 'FOG_GLOW'
    if 'Threshold' in glow.inputs:
        glow.inputs['Threshold'].default_value = s.glow_threshold
    else:
        glow.threshold = s.glow_threshold
    render = next((n for n in nodes if n.type == 'R_LAYERS'), None)
    if render is None:
        render = nodes.new('CompositorNodeRLayers')
        render.location = (-100, 80)
    composite = next((n for n in nodes if n.type == 'COMPOSITE'), None)
    if composite is None:
        composite = nodes.new('CompositorNodeComposite')
        composite.location = (460, 80)
    # NOTE: only rewires Composite input when user explicitly requests glow.
    links.new(render.outputs['Image'], glow.inputs['Image'])
    out = glow.outputs.get('Image') or glow.outputs[0]
    links.new(out, composite.inputs['Image'])


class ASS_OT_generate(Operator):
    bl_idname = 'ass.generate_palette'
    bl_label = 'Generate Palette'
    bl_description = 'Fill custom color swatches with generated tonal shades'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.ass_settings
        ensure_palette(s)
        for item, c in zip(s.palette, generated(s)):
            item.color = c
        s.palette_mode = 'CUSTOM'
        return {'FINISHED'}


class ASS_OT_extract(Operator):
    bl_idname = 'ass.extract_palette'
    bl_label = 'Extract Image Palette'
    bl_description = 'Cluster image colors into a sorted shadow-to-light palette'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.ass_settings
        img = s.source_image
        if not img:
            self.report({'ERROR'}, 'Choose a reference image first')
            return {'CANCELLED'}
        try:
            pixels = img.pixels[:]
        except Exception:
            self.report({'ERROR'}, 'Image pixels unavailable; load/unpack the image')
            return {'CANCELLED'}
        channels = img.channels
        if channels < 3 or not pixels:
            self.report({'ERROR'}, 'Image has no RGB pixels')
            return {'CANCELLED'}
        count = len(pixels)//channels
        rng = random.Random(1138)
        indices = rng.sample(range(count), min(count, s.sample_limit))
        samples = [tuple(float(pixels[i*channels+j]) for j in range(3)) for i in indices
                   if channels < 4 or pixels[i*channels+3] >= 0.1]
        if not samples:
            self.report({'ERROR'}, 'No opaque image colors found')
            return {'CANCELLED'}
        # Seed centroids with well-spaced luminance-ranked samples.
        samples.sort(key=color_value)
        k = s.bands
        centroids = [list(samples[round(i*(len(samples)-1)/(k-1))]) for i in range(k)]
        for _ in range(15):
            clusters = [[] for _ in range(k)]
            for color in samples:
                idx = min(range(k), key=lambda j: sum((color[d]-centroids[j][d])**2 for d in range(3)))
                clusters[idx].append(color)
            for i, cluster in enumerate(clusters):
                if cluster:
                    centroids[i] = [sum(c[d] for c in cluster)/len(cluster) for d in range(3)]
        centroids.sort(key=color_value)
        ensure_palette(s)
        for i, color in enumerate(centroids):
            s.palette[i].color = (*[max(0,min(1,v)) for v in color], 1)
        s.palette_mode = 'IMAGE'
        self.report({'INFO'}, f'Extracted {k} colors')
        return {'FINISHED'}


class ASS_OT_apply(Operator):
    bl_idname = 'ass.apply_material'
    bl_label = 'Create / Update Toon Material'
    bl_description = 'Apply toon material to selected meshes; update any existing Anime Shader materials'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.ass_settings
        objs = [ob for ob in context.selected_objects if ob.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, 'Select at least one mesh')
            return {'CANCELLED'}
        if context.scene.render.engine != 'BLENDER_EEVEE_NEXT':
            context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
        updated = 0
        for obj in objs:
            mats = [m for m in obj.data.materials if m and m.get('ass_material')]
            mat = mats[0] if mats else bpy.data.materials.new(PREFIX + 'Toon')
            build_material(s, mat)
            if not mats:
                if len(obj.data.materials) == 0:
                    obj.data.materials.append(mat)
                else:
                    obj.data.materials[0] = mat
            updated += 1
        self.report({'INFO'}, f'Applied toon shading to {updated} mesh(es)')
        return {'FINISHED'}


class ASS_OT_outlines(Operator):
    bl_idname = 'ass.setup_outlines'
    bl_label = 'Apply Outline Settings'
    bl_description = 'Configure Freestyle line sets for all view layers; renders only'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            setup_outlines(context, context.scene.ass_settings)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Freestyle outlines updated (visible in F12 renders)')
        return {'FINISHED'}


class ASS_OT_glow(Operator):
    bl_idname = 'ass.setup_glow'
    bl_label = 'Apply Glow Compositor'
    bl_description = 'Add/update/remove managed glow node (enabling glow replaces Composite image input)'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            setup_glow(context.scene, context.scene.ass_settings)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Glow compositor updated')
        return {'FINISHED'}


class ASS_PT_panel(Panel):
    bl_label = 'Anime Shader Studio'
    bl_idname = 'ASS_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Anime Shader'

    def draw(self, context):
        s = context.scene.ass_settings
        layout = self.layout
        layout.label(text='EEVEE / Scene-lit Toon Shader', icon='SHADING_RENDERED')
        box = layout.box()
        box.label(text='1. Color & Lighting', icon='COLOR')
        box.prop(s, 'bands')
        box.prop(s, 'palette_mode')
        if s.palette_mode == 'GENERATED':
            box.prop(s, 'base_color')
            box.prop(s, 'shadow_strength')
            box.prop(s, 'highlight_strength')
            box.operator('ass.generate_palette', icon='BRUSH_DATA')
        if s.palette_mode == 'IMAGE':
            box.prop(s, 'source_image')
            box.prop(s, 'sample_limit')
            box.operator('ass.extract_palette', icon='IMAGE_DATA')
        if s.palette_mode in {'CUSTOM', 'IMAGE'}:
            ensure_palette(s)
            for i, item in enumerate(s.palette):
                box.prop(item, 'color', text=f'Band {i+1}')
        box.prop(s, 'grayscale')
        box.prop(s, 'light_gain')
        box.prop(s, 'band_offset')
        box.prop(s, 'band_spread')
        box = layout.box()
        box.label(text='2. Glossy / Emission', icon='LIGHT_SUN')
        box.prop(s, 'gloss')
        if s.gloss:
            box.prop(s, 'roughness')
            box.prop(s, 'gloss_threshold')
            box.prop(s, 'gloss_color')
            box.prop(s, 'gloss_strength')
        box.prop(s, 'emission')
        if s.emission:
            box.prop(s, 'emission_color')
            box.prop(s, 'emission_strength')
        box = layout.box()
        box.label(text='3. Freestyle Ink', icon='OUTLINER_OB_GREASEPENCIL')
        box.prop(s, 'outline')
        if s.outline:
            box.prop(s, 'outer_thickness')
            box.prop(s, 'use_crease')
            if s.use_crease:
                box.prop(s, 'inner_thickness')
                box.prop(s, 'crease_angle')
            box.prop(s, 'use_material_edges')
            box.prop(s, 'outer_taper')
            if s.outer_taper:
                box.prop(s, 'outer_taper_length')
            if s.use_crease:
                box.prop(s, 'inner_taper')
                if s.inner_taper:
                    box.prop(s, 'inner_taper_length')
                    box.prop(s, 'inner_stroke_split')
                    if s.inner_stroke_split:
                        box.prop(s, 'inner_split_length')
            if s.outer_taper or (s.use_crease and s.inner_taper):
                box.prop(s, 'taper_tip')
            box.prop(s, 'outline_color')
        box.operator('ass.setup_outlines', icon='MOD_LINEART')
        box = layout.box()
        box.label(text='4. Post-processing Glow', icon='LIGHT')
        box.prop(s, 'glow')
        if s.glow:
            box.prop(s, 'glow_threshold')
        box.operator('ass.setup_glow', icon='NODE_COMPOSITING')
        layout.separator()
        layout.operator('ass.apply_material', icon='MATERIAL', text='Create / Update Selected Materials')
        layout.label(text='Lines and glow: F12 render, not live viewport', icon='INFO')


classes = (ASS_PaletteColor, ASS_Settings, ASS_OT_generate, ASS_OT_extract,
           ASS_OT_apply, ASS_OT_outlines, ASS_OT_glow, ASS_PT_panel)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ass_settings = PointerProperty(type=ASS_Settings)


def unregister():
    del bpy.types.Scene.ass_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
